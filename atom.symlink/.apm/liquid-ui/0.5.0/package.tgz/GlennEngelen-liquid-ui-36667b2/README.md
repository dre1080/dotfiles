# Liquid UI theme

A bright Atom theme for a modern experience.<br>
(Work in progress)

## Installation
```
apm install liquid-ui liquid-syntax
```

## Screenshot
![](http://www.epicbrands.be/images/atom.png)
