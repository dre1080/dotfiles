# liquid-syntax theme

A bright Atom syntax theme for a modern experience.

## Installation
```
apm install liquid-ui liquid-syntax
```

## Screenshot

![](http://www.epicbrands.be/images/atom.png)
